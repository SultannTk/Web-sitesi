<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        
        header a{
            text-decoration: none;
         color: aliceblue;
        }
        
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        section{
            text-align: center;
            width: 500px;
            border: 1px;
            border-style: solid;
            margin-top: 25px;
            font-size: 25px;
            background-color: rgb(255, 251, 236);
        }
        section p{
            font-style: italic;
        }
        .buttons{
            background-color:rgb(70, 104, 104);
            border-radius:10px;
            padding:8px 10px;
            float:right;
            text-decoration:none;
            margin-left:5px;
        }
    </style>
</head>
<body>
   
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="sayfa1.php#tür">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>
        <center>
            <br>
            <iframe width="560" height="315" src="https://youtu.be/nkDFoVl9APA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        <section>
            <h2>Ben Sana Mecburum</h2>
            <p>Ben sana mecburum bilemezsin<br>
Adını mıh gibi aklımda tutuyorum<br>
Büyüdükçe büyüyor gözlerin<br>
Ben sana mecburum bilemezsin<br>
İçimi seninle ısıtıyorum<br><br>

Ağaçlar sonbahara hazırlanıyor<br>
Bu şehir o eski İstanbul mudur?<br>
Karanlıkta bulutlar parçalanıyor<br>
Sokak lambaları birden yanıyor<br>
Kaldırımlarda yağmur kokusu<br>
Ben sana mecburum sen yoksun<br><br>

Sevmek kimi zaman rezilce korkudur<br>
İnsan bir akşam üstü ansızın yorulur<br>
Tutsak ustura ağzında yaşamaktan<br>
Kimi zaman ellerini kırar tutkusu<br>
Birkaç hayat çıkarır yaşamasından<br>
Hangi kapıyı çalsa kimi zaman<br>
Arkasında yalnızlığın hınzır uğultusu<br><br>

Fatihte yoksul bir gramafon çalıyor<br>
Eski zamanlardan bir Cuma çalıyor<br>
Durup köşe başında deliksiz dinlesem<br>
Sana kullanılmamış bir gök getirsem<br>
Haftalar ellerimde ufalanıyor<br>
Ne yapsam ne tutsam nereye gitsem<br>
Ben sana mecburum sen yoksun<br><br>

Belki Haziranda mavi benekli çocuksun<br>
Ah seni bilmiyor kimseler bilmiyor<br>
Bir şilep sızıyor ıssız gözlerinden<br>
Belki Yeşilköy'de uçağa biniyorsun<br>
Bütün ıslanmışsın tüylerin ürperiyor<br>
Belki körsün kırılmışsın telâş içindesin<br>
Kötü rüzgâr saçlarını götürüyor<br><br>

Ne vakit bir yaşamak düşünsem<br>
Bu kurtlar sofrasında belki zor<br>
Ayıpsız fakat ellerimizi kirletmeden<br>
Ne vakit bir yaşamak düşünsem<br>
Sus deyip adınla başlıyorum<br>
İçim sıra kımıldıyor gizli denizlerin<br>
Hayır başka türlü olmayacak<br>
Ben sana mecburum bilemezsin..<br><br>
                
                &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; Orhan Veli Kanık</p>
        </section>
        </center>
       
        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>