<?php
include 'baglanti.php'; 


if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Hata: Geçerli bir şiir ID'si belirtilmedi.");
}

$id = $_GET['id'];


$stmt = $baglan->prepare("SELECT siirler.id, siirler.baslik, siirler.siir, siirler.sair, kategoriler.kategori_adi 
                          FROM siirler 
                          INNER JOIN kategoriler ON siirler.kategori_id = kategoriler.id 
                          WHERE siirler.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    die("Hata: Şiir bulunamadı.");
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şiir Detay</title>
    <style>
        body {
            margin: 0;
            background-color:rgb(237, 229, 205);
            font-family: Arial, sans-serif;
        }
        header {
            background-color: rgb(70, 104, 104);
            color: white;
            text-align: center;
            padding: 20px;
        }
        header h1 {
            margin: 0;
        }
        .content {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .content h2 {
            color: rgb(127, 73, 131);
            font-size: 32px;
            margin-bottom: 10px;
            font-style: italic;
        }
        .content p {
            font-size: 18px;
            line-height: 1.6;
        }
        .content .details {
            margin-top: 20px;
            font-size: 16px;
            color: rgb(70, 104, 104);
        }
        .content .back-btn {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background-color: rgb(127, 73, 131);
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .content .back-btn:hover {
            background-color: rgb(100, 56, 103);
        }
        .poem p{
            font-style: italic;
        }
        
    </style>
</head>
<body>

<header>
    <h1>POEMIX - Şiir Detayı</h1>
</header>

<div class="content">
    <h2><?php echo htmlspecialchars($row['baslik']); ?></h2>
    <p><strong>Şair:</strong> <?php echo htmlspecialchars($row['sair']); ?></p>
    <p><strong>Kategori:</strong> <?php echo htmlspecialchars($row['kategori_adi']); ?></p>
    
    <div class="poem">
        <h3>Şiir:</h3>
        <p><?php echo nl2br(htmlspecialchars($row['siir'])); ?></p>
    </div>

    <a href="index.php" class="back-btn">Geri Dön</a>
</div>

</body>
</html>
