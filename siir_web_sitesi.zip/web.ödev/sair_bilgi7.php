<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a{
            text-decoration: none;
            color: aliceblue;
        }
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        .hayat{
            width: 80%;
            height: 700px;
            margin-left: 180px;
            margin-top: 50px;
        }
        .hayat img{
            width: 200px;
            height: 200px;
            border-radius: 100px;
        }
    </style>
</head>
<body>
   
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php#tür">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>

        <div class="hayat">
            <center>
                <img src="Orhan.jpg" alt="">
            <h2>ORHAN VELİ KANIK</h2>
            </center>
            <p>Orhan Veli Kanık (13 Nisan 1914, İstanbul – 14 Kasım 1950, İstanbul), daha çok Orhan Veli olarak tanınan Türk şairdir. Melih Cevdet ve Oktay Rifat ile birlikte yenilikçi Garip akımının kurucusu olan Kanık, Türk şiirindeki eski yapıyı temelinden değiştirmeyi amaçlayarak sokaktaki adamın söyleyişini şiir diline taşıdı.[3] Şair otuz altı yıllık yaşamına şiirlerinin yanı sıra hikâye, deneme, makale ve çeviri alanında birçok eser sığdırdı.[4]

Yeni bir zevk ortaya çıkarabilmek için eski olan her şeyden uzak duran Orhan Veli, hece ve aruz ölçülerini kullanmayı reddetti. Kafiyeyi ilkel; mecaz, teşbih, mübalağa gibi edebi sanatları gereksiz bulduğunu açıkladı. "Geçmiş edebiyatların öğrettiği her şeyi, bütün geleneği atmak" amacıyla yola çıkan Kanık'ın bu arzusu şiirinde kullanabileceği teknik olanakları azaltsa da şair, ele aldığı konular, bahsettiği kişiler ve kullandığı sözcüklerle kendine yeni alanlar oluşturdu.[5] Yalın bir anlatımı benimseyerek şiir dilini konuşma diline yaklaştırdı. 1941 yılında, arkadaşlarıyla birlikte çıkardıkları Garip adlı şiir kitabında bu fikirlerinin örnekleri olan şiirleri yayınlandı ve Garip akımının doğmasına sebep oldu. Bu akım özellikle 1940-1950 yılları arasında Cumhuriyet dönemi şiirinde büyük etki bıraktı.[6] Garip şiiri hem yıkıcı hem de yapıcı özelliği ile Türk şiirinde bir mihenk taşı kabul edilir.[7]

Kanık, şiire getirdiği bu yenilikler yüzünden önceleri büyük ölçüde yadırgandı, çok sert eleştiriler aldı ve küçümsendi.[I][6][8][9] Geleneklerin dışına çıkan eserleri, önce şaşkınlık ve yadırgama, daha sonra eğlenme ve aşağılamayla karşılansa da hep ilgi uyandırdı.[5] Bu ilgi ise kısa zamanda şaire duyulan anlayış, sevgi ve hayranlığın artmasına yol açtı.[5] Sait Faik Abasıyanık da Orhan Veli'nin bu yönüne dikkat çekerek onu "üzerinde en çok durulmuş, zaman zaman alaya alınmış, zaman zaman kendini kabul ettirmiş, tekrar inkâr, tekrar kabul edilmiş; zamanında hem iyi hem kötü şöhrete ermiş bir şair" olarak tanımladı.[10]

Her ne kadar Garip döneminde yazdığı şiirleriyle öne çıksa da Orhan Veli "tek tür" şiirler yazmaktan kaçınmıştı. Durmadan arayan, kendini yenileyen, kısa yaşamı boyunca uzun bir şiir serüveni yaşayan Kanık'ın edebiyat hayatı farklı aşamalardan oluşmaktadır.[11] Oktay Rifat bu durumu "Orhan Fransız şairlerinin birkaç nesillik şiir macerasını kısacık ömründe yaşadı. Türk şiiri onun kalemi sayesinde Avrupa şiiriyle atbaşı geldi." ve "Birkaç neslin belki arka arkaya başarabileceği bir değişmeyi o birkaç yılın içinde tamamladı." sözleriyle açıkladı.</p>
        </div>
     
        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>