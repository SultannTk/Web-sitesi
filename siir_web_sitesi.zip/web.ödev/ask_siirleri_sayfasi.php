<?php include'header.php';?>
    <style>
        body {
            margin: 0px;
            background-image: url(love_background.jpg);
            background-repeat: no-repeat;
            background-size: cover;
        }
        header img {
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header {
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a {
            text-decoration: none;
            color: aliceblue;
        }
        header p {
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav {
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border: 1px solid black;
        }
        nav a {
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover {
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer {
            background-color: rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            margin-top: 20px;
        }
        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }
        .card {
            background-color: rgba(255, 255, 255, 0.9);
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
            padding: 15px;
        }
        .card h3 {
            color: rgb(127, 73, 131);
            margin: 0;
            font-style: italic;
        }
        .card p {
            margin: 10px 0;
        }
        .card a {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 15px;
            background-color: rgb(127, 73, 131);
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .card a:hover {
            background-color: rgb(100, 56, 103);
        }
    </style>
</head>
<body>
    
    <nav>
        <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php#tür">Türler</a> | <a href="#">Üyeler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir Ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
    </nav>

    <div class="card-container">
        <?php
        include 'baglanti.php';

        
        $sql = "SELECT siirler.id, siirler.baslik, siirler.sair, kategoriler.kategori_adi 
                FROM siirler 
                INNER JOIN kategoriler ON siirler.kategori_id = kategoriler.id";
        $result = $baglan->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "
                <div class='card'>
                    <h3>" . htmlspecialchars($row['baslik']) . "</h3>
                    <p><strong>Şair:</strong> " . htmlspecialchars($row['sair']) . "</p>
                    <p><strong>Kategori:</strong> " . htmlspecialchars($row['kategori_adi']) . "</p>
                    <a href='siir_detay.php?id=" . $row['id'] . "'>Detaylı İncele</a>
                </div>";
            }
        } else {
            echo "<p>Henüz eklenen bir şiir yok.</p>";
        }

        $baglan->close();
        ?>
    </div>

    

    <footer>
        &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
    </footer>
</body>
</html>
