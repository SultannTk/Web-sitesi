<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a{
            text-decoration: none;
            color: aliceblue;
        }
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        .hayat{
            width: 80%;
            height: 700px;
            margin-left: 180px;
            margin-top: 50px;
        }
        .hayat img{
            width: 200px;
            height: 200px;
            border-radius: 100px;
        }
    </style>
</head>
<body>
    
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php#tür">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>

        <div class="hayat">
            <center>
                <img src="Cahit.jpg" alt="">
            <h2>CAHİT SITKI TARANCI</h2>
            </center>
            <p> Cahit Sıtkı Tarancı, Diyarbakır'ın en zengin ailenin bir ferdi olarak dünyaya gelmiştir. Suriçi Cami Kebir Mahallesinde doğan Tarancı, çocukluk ve gençlik dönemlerini burada geçirmiştir. İlköğretim yıllarını Diyarbakır'da tamamlayan Tarancı, liseye başlayacağı dönemde ailesi tarafından İstanbul'a yollanmıştır. İlk önce Kadıköy Fransız Saint Joseph Lisesine kaydolan Tarancı, ardından Galatasaray Lisesine geçip, lise hayatını orada tamamlamıştır. O senelerde ana dil derecesinde Fransızca dilini öğrenmiştir.

Lise yıllarında şiire ve edebiyata ilgi gösteren Cahit Sıtkı Tarancı, Galatasaray Lisesin önemli bir dergisi için şiir yazmıştır. Bu şiirleri sayesinde tanınan ve şiirleri sayesinde isminden sıklıkla söz ettiren Tarancı, ilerleyen dönemlerde en popüler edebiyat dergisi olan Servet-i Fünun için yazmaya başlamıştır. Burada şiirlerini yayınlayan Cahit Sıtkı, Ziya Osman Saba ile tanışarak dost olmuştur. Cahit Sıtkı'nın yaşamında dostu için yazmış olduğu mektuplar, ölümü sonrasında bir araya getirilerek eser halinde okurlara sunulmuştur.

Servet-i Fünun dergisinde şiirleri yayınlanmaya devam eden Tarancı 1931- 35 senelerimde İstanbul Mülkiye Mektebinde ve Yüksek Ticaret Okulu ile eğitimine devam etmiştir. O senelerde ise ''Ömrümde Sükut'' isimli şiir kitabını yayınlamıştır. Mezun olan Tarancı, Sümerbankta memur olarak çalışmaya başlamıştır. O zamanlar Tarancı'nın Peyami Safa'yla tanışması, hayatının en önemli konusuydu. Peyami Safa ile Tarancı'nın şiirleri Cumhuriyet Gazetesinde yayınlanarak, çok ilgi toplamıştır.</p>
        </div>
     
        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>