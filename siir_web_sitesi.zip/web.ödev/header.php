<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POEMIX.COM</title>
    <link rel="shortcut icon" href="logo.webp" type="image/x-icon">
<header>
        <a href="index.php">
        <img src="logo.webp" alt="logo">
        <p>
            POEMIX
        </p></a>
             <input style="border-radius: 14px; margin-left: 230px; width: 400px; height: 30px; margin-top: 0px; display: inline-block;" placeholder="Şiir ara..." type="text">   
        </div>
            
        <div style="float: right; margin-right: 40px; color:black ; text-decoration: none;">
            <button style="width: 100px; height: 30px; border-radius: 10px;"> <a  style="color:black; text-decoration:none;" href="giris.php"> GİRİŞ YAP</a></button>
            <button style="width: 100px; height: 30px; border-radius: 10px; "> <a  style="color:black; text-decoration:none;" href="kayit.php">KAYIT OL</a></button>
        </div>
        <div style="clear: both;"></div>
       
    </header> 