<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anapanel</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        a {
            text-decoration: none;
            margin-right: 10px;
        }
        .button {
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .button.delete {
            background-color: #f44336;
        }
        .button.edit {
            background-color: #2196F3;
        }
    </style>
</head>
<body>
    <h1>Ana Panel</h1>
    <a href="kategori_ekle.php" class="button">Kategori Ekle</a>
    <a href="siir_ekle.php" class="button">Şiir Ekle</a>

    <h2>Kategoriler ve Şiirler</h2>
    <?php
    include 'baglanti.php'; 
    include 'gelenlerpanel.php' ;

    
    $kategori_sorgu = "SELECT * FROM kategoriler";
    $kategori_sonuc = $baglan->query($kategori_sorgu);

    if ($kategori_sonuc->num_rows > 0) {
        while ($kategori = $kategori_sonuc->fetch_assoc()) {
            echo "<h3>" . htmlspecialchars($kategori['kategori_adi']) . "</h3>";
            echo "<p>" . htmlspecialchars($kategori['kategori_aciklama']) . "</p>";

            $siir_sorgu = $baglan->prepare("SELECT * FROM siirler WHERE kategori_id = ?");
            $siir_sorgu->bind_param("i", $kategori['id']);
            $siir_sorgu->execute();
            $siir_sonuc = $siir_sorgu->get_result();

            if ($siir_sonuc->num_rows > 0) {
                echo "<table>
                        <tr>
                            <th>ID</th>
                            <th>Başlık</th>
                            <th>Şair</th>
                            <th>İşlemler</th>
                        </tr>";
                while ($siir = $siir_sonuc->fetch_assoc()) {
                    echo "<tr>
                            <td>{$siir['id']}</td>
                            <td>{$siir['baslik']}</td>
                            <td>{$siir['sair']}</td>
                            <td>
                                <a href='siir_duzenle.php?id={$siir['id']}' class='button edit'>Düzenle</a>
                                <a href='siir_sil.php?id={$siir['id']}' onclick=\"return confirm('Bu şiiri silmek istediğinize emin misiniz?');\" class='button delete'>Sil</a>
                            </td>
                          </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>Bu kategoride henüz şiir yok.</p>";
            }
            $siir_sorgu->close();
        }
    } else {
        echo "<p>Henüz kategori eklenmemiş.</p>";
    }
    $baglan->close();
    ?>

</body>
</html>
