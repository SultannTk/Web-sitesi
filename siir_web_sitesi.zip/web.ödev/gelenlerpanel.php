<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even) {
  background-color: #f2f2f2;
}

#customers tr:hover {
  background-color: #ddd;
}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: rgb(70, 104, 104);
  color: white;
}

.button {
  padding: 5px 10px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  text-decoration: none;
}

.button.delete {
  background-color: #f44336;
}

.button.edit {
  background-color: #2196F3;
}
</style>
</head>
<body>

<h1>Gelen Şiirler</h1>

<table id="customers">
  <tr>
    <th>Kullanıcı Adı</th>
    <th>Şiir Türü</th>
    <th>Şiir</th>
    <th>İşlemler</th>
  </tr>

  <?php
include("baglanti.php");

$sec = "SELECT * FROM eklenen";
$sonuc = $baglan->query($sec);

if ($sonuc->num_rows > 0) {
    while ($cek = $sonuc->fetch_assoc()) {
        echo "
        <tr>
            <td>" . htmlspecialchars($cek['kullaniciAdi']) . "</td>
            <td>" . htmlspecialchars($cek['ŞiirTürü']) . "</td>
            <td>" . htmlspecialchars($cek['Şiir']) . "</td>
            <td>
                <a href='gelen_siir_duzenle.php?id=" . $cek['id'] . "' class='button edit'>Düzenle</a>
                <a href='gelen_siir_sil.php?id=" . $cek['id'] . "' onclick=\"return confirm('Bu şiiri silmek istediğinize emin misiniz?');\" class='button delete'>Sil</a>
            </td>
        </tr>
        ";
    }
} else {
    echo "<tr><td colspan='4'>Veritabanında kayıtlı hiçbir veri bulunamamıştır</td></tr>";
}
?>

</table>

</body>
</html>
