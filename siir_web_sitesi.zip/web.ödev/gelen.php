<?php
include("baglanti.php"); 
?>

<?php include'header.php';?>
    <style>
        body {
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img {
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header {
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a {
            text-decoration: none;
            color: aliceblue;
        }
        header p {
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav {
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border: 1px solid;
        }
        nav a {
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover {
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer {
            background-color: rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px solid;
            margin-top: 20px;
        }
        .container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background-color: white;
            width: 300px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            background-color: rgb(70, 104, 104);
            color: white;
            padding: 15px;
            font-size: 20px;
            text-align: center;
        }
        .card-body {
            padding: 15px;
        }
        .card-body p {
            margin: 10px 0;
        }
        .card-footer {
            text-align: center;
            padding: 10px;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    
    <nav>
        <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
    </nav>

    <div class="container">
        <?php
        $sorgu = "SELECT * FROM eklenen"; 
        $sonuc = $baglan->query($sorgu);

        if ($sonuc->num_rows > 0) {
            while ($satir = $sonuc->fetch_assoc()) {
                echo '
                <div class="card">
                    <div class="card-header">' . htmlspecialchars($satir["kullaniciAdi"]) . '</div>
                    <div class="card-body">
                        <p><strong>Tür:</strong> ' . htmlspecialchars($satir["ŞiirTürü"]) . '</p>
                        <p>' . nl2br(htmlspecialchars($satir["Şiir"])) . '</p>
                    </div>
                    <div class="card-footer">
                        <small>Gönderildi</small>
                    </div>
                </div>';
            }
        } else {
            echo '<p>Henüz gönderilmiş bir şiir yok.</p>';
        }
        ?>
    </div>

    <footer>
        &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
    </footer>
</body>
</html>
