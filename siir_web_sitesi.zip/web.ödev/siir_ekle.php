<?php
include 'baglanti.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kategori_id = $_POST['kategori_id'];
    $baslik = $_POST['baslik'];
    $siir = $_POST['siir'];
    $sair = $_POST['sair'];

    $stmt = $baglan->prepare("INSERT INTO siirler (kategori_id, baslik, siir, sair) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $kategori_id, $baslik, $siir, $sair);

    if ($stmt->execute()) {
        echo "Şiir başarıyla eklendi!";
    } else {
        echo "Hata: " . $stmt->error;
    }

    $stmt->close();
    $baglan->close();
}
?>

<form action="siir_ekle.php" method="POST">
    <label>Kategori:</label>
    <select name="kategori_id" required>
        <?php
        include 'baglanti.php';
        $kategori_sorgu = "SELECT * FROM kategoriler";
        $kategori_sonuc = $baglan->query($kategori_sorgu);

        while ($kategori = $kategori_sonuc->fetch_assoc()) {
            echo "<option value='{$kategori['id']}'>" . htmlspecialchars($kategori['kategori_adi']) . "</option>";
        }

        $baglan->close();
        ?>
    </select><br>

    <label>Başlık:</label>
    <input type="text" name="baslik" required><br>

    <label>Şiir:</label>
    <textarea name="siir" required></textarea><br>

    <label>Şair:</label>
    <input type="text" name="sair" required><br>

    <button type="submit">Şiir Ekle</button>
</form>
