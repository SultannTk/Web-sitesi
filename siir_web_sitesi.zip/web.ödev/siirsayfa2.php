<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        
        header a{
            text-decoration: none;
         color: aliceblue;
        }
        
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        section{
            text-align: center;
            width: 500px;
            border: 1px;
            border-style: solid;
            margin-top: 25px;
            font-size: 25px;
            background-color: rgb(255, 251, 236);
        }
        section p{
            font-style: italic;
        }
        .buttons{
            background-color:rgb(70, 104, 104);
            border-radius:10px;
            padding:8px 10px;
            float:right;
            text-decoration:none;
            margin-left:5px;
        }
    </style>
</head>
<body>
    
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="sayfa1.php#tür">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>
        <center>
            <br>
            <iframe width="560" height="315" src="https://youtu.be/mSIPT-hyHac" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        <section>
            <h2>Eğer</h2>
            <p>Okadar da önemli değildir bırakıp gitmeler,<br>
Arkalarında doldurulması mümkün olmayan boşluklar bırakılmasaydı eğer.<br><br>
Atanılacak bir şey değildir ağlamak,<br>
Yürekten süzülüp geliyorsa gözyaşı eğer…<br><br>
Belirsizliğe yelken açardı iri ela gözler zamanla,<br>
Öylesine derince bakmasalardı eğer…<br><br>
Çabuk unutulurdu ıslak bir öpücüğün yakıcı tadı belki de,<br>
Kalp,göğüs kafesine o kadar yüklenmeseydi eğer…<br><br>

Düşlere bile kar yağmazdı hiçbir zaman<br>
Meydan savaşlarında korkular aşkı ağır yaralamasaydı eğer…<br><br>
Rengi bile solardı düşlerdeki saçların zamanla,<br>
Tanımsız kokuları yastıklara yapışıp kalmasaydı eğer…<br><br>
Uykusuzluklar yıkıp geçmezdi kısacık kestirmelerin ardından,<br>
Dokunulası ipek ten bir o kadar uzakta olmasaydı eğer…<br><br>
Gerçekten boynunu bükmezdi papatyalar,<br>
İhanetinden de onlar payını almasaydı eğer…<br><br>
Issızlığa teslim olmazdı sahiller,<br>
Kendi belirsiz sahillerinde amaçsız gezintilerle avunmaya kalkmamış olsaydın eğer…<br><br>

Sen gittikten sonra yalnız kalacağım<br>
Yalnız kalmaktan korkmuyorum da, ya canım ellerini tutmak isterse?<br><br>

Evet sevgili,<br>
Kim özlerdi avuç içlerinin ter kokusunu,<br>
Kim uzanmak isterdi ince parmaklarına,<br>
Mazilerinde görkemli bir yaşanmışlığa tanıklık etmiş olmasalardı eğer…<br>
                
                &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp; Can Yücel</p>
        </section>
        </center>
       
        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>