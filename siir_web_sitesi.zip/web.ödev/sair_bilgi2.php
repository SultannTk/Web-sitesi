<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a{
            text-decoration: none;
            color: aliceblue;
        }
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        .hayat{
            width: 80%;
            height: 700px;
            margin-left: 180px;
            margin-top: 50px;
        }
        .hayat img{
            width: 200px;
            height: 200px;
            border-radius: 100px;
        }
    </style>
</head>
<body>
    
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php#tür">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>

        <div class="hayat">
            <center>
                <img src="ATTİLA İLHAN.webp" alt="">
            <h2>ATTİLA İLHAN</h2>
            </center>
            <p>15 Haziran 1925'te İzmir, Menemen'de doğdu. İlk ve orta eğitiminin büyük bir bölümünü İzmir ve babasının işi dolayısıyla gittikleri farklı bölgelerde tamamladı. İzmir Atatürk Lisesi'nin birinci sınıfındayken mektuplaştığı bir kıza yazdığı Nâzım Hikmet şiirleriyle yakalanmasıyla 1941 Şubat'ında, 16 yaşındayken tutuklandı ve okuldan uzaklaştırıldı. Üç hafta gözaltında kaldı. İki ay hapiste yattı. Türkiye'nin hiçbir yerinde okuyamayacağına dair bir belge verilince, eğitim hayatına ara vermek zorunda kaldı. Danıştay kararıyla, 1944 yılında okuma hakkını tekrar kazandı ve İstanbul Işık Lisesi'ne yazıldı. Lise son sınıftayken amcasının kendisinden habersiz katıldığı CHP Şiir Armağanı'nda Cebbaroğlu Mehemmed şiiriyle dönemin pek çok ünlü şairini geride bırakarak ikincilik ödülünü aldı. 1946'da mezun oldu. İstanbul Üniversitesi Hukuk Fakültesine kaydoldu. Üniversite yaşamının başarılı geçen yıllarında Yığın ve Gün gibi dergilerde ilk şiirleri yayımlanmaya başladı. 1948'de ilk şiir kitabı Duvar'ı kendi olanaklarıyla yayımladı. Kısa süren ilk Paris deneyiminin ardından yurda döndü. Gerçek gazetesinde yayımlamaya başladığı yazılarla siyasal tartışmaların içine girdi. Bu nedenle eğitimini savsaklayan Attilâ İlhan, İstanbul Üniversitesi Hukuk Fakültesindeki öğrenimini yarıda bırakmak zorunda kaldı.[8]</p>
        </div>
     
        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>