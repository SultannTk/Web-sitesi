<?php
include 'baglanti.php'; 


if (isset($_GET['kategori'])) {
    $kategori_adi = $_GET['kategori'];
} else {
    die("Kategori belirtilmedi.");
}


$stmt = $baglan->prepare("SELECT siirler.id, siirler.baslik, siirler.sair, siirler.siir, kategoriler.kategori_adi 
                          FROM siirler 
                          INNER JOIN kategoriler ON siirler.kategori_id = kategoriler.id 
                          WHERE kategoriler.kategori_adi = ? 
                          ORDER BY siirler.tarih DESC");
$stmt->bind_param("s", $kategori_adi); 
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $kategori_adi; ?> Şiirleri</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: rgb(70, 104, 104);
            color: white;
            text-align: center;
            padding: 20px;
        }
        .poem-card {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            margin: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .poem-card h3 {
            margin: 0;
            color: rgb(127, 73, 131);
        }
        .poem-card p {
            font-size: 16px;
        }
        .back-btn {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background-color: rgb(127, 73, 131);
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-btn:hover {
            background-color: rgb(100, 56, 103);
        }
    </style>
</head>
<body>

<header>
    <h1><?php echo htmlspecialchars($kategori_adi); ?> Şiirleri</h1>
</header>

<div class="content">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div class='poem-card'>
                    <h3>" . htmlspecialchars($row['baslik']) . "</h3>
                    <p><strong>Şair:</strong> " . htmlspecialchars($row['sair']) . "</p>
                    <p><strong>Şiir:</strong><br>" . nl2br(htmlspecialchars($row['siir'])) . "</p>
                    <a href='siir_detay.php?id=" . $row['id'] . "' class='back-btn'>Detayı Gör</a>
                  </div>";
        }
    } else {
        echo "<p>Bu kategoride herhangi bir şiir bulunmamaktadır.</p>";
    }
    ?>
</div>

<a href="index.php" class="back-btn">Ana Sayfaya Dön</a>

</body>
</html>

<?php

$baglan->close();
?>
