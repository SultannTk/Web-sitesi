<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a{
            text-decoration: none;
            color: aliceblue;
        }
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        .hayat{
            width: 80%;
            height: 700px;
            margin-left: 180px;
            margin-top: 50px;
        }
        .hayat img{
            width: 200px;
            height: 200px;
            border-radius: 100px;
        }
    </style>
</head>
<body>
   
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php#tür">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>

        <div class="hayat">
            <center>
                <img src="Can.webp" alt="">
            <h2>CAN YÜCEL</h2>
            </center>
            <p>Can Yücel dünyaca tanınan modern Türk şairdir.

Kullandığı kaba ama samimi dil ile Türk şiirinde farklı bir tarz yaratmıştır.Can Yücel, 1926'da İstanbul'da doğdu.Hasan Ali Yücel’in oğludur.Ankara ve Cambridge üniversitelerinde Latince ve Yunanca okudu. Çeşitli elçiliklerde çevirmenlik, Londra’da BBC’nin Türkçe bölümünde spikerlik yaptı

.Askerliğini Kore’de yaptı. 1958’de Türkiye’ye döndükten sonra bir süre Bodrum’da turist rehberi olarak çalıştı. Ardından bağımsız çevirmen ve şair olarak yaşamını İstanbul’da sürdürdü. 1956 yılında Güler Yücel ile evlendi. Bu evlilikten iki kızı (Güzel ve Su) ve bir oğlu (Hasan) oldu.

Son yıllarında Datça’ya yerleşti ve her hafta Leman, her ay Öküz dergilerinde yazıları ve şiirleri yayımlandı. Cumhurbaşkanı Süleyman Demirel`e hakaretten yargılanan Yücel, 18 Nisan seçimlerinde ÖDP`nin İzmir 1. sıra milletvekili adayı oldu. 12 Ağustos 1999 gecesi ölen şair, çok sevdiği günebakan çiçekleriyle uğurlanarak Datça'ya gömüldü.

Can Yücel, 1945-1965 yılları arasında `Yenilikler`, `Beraber`, `Seçilmiş Hikayeler`, `Dost`, `Sosyal Adalet`, `Şiir Sanatı`, `Dönem`,`Ant`, `İmece` ve `Papirüs` adlı dergilerde yazdı. Daha sonraları `Yeni Dergi`, ‘Birikim`, `Sanat Emeği`, `Yazko Edebiyat` ve `Yeni Düşün` dergilerinde yayımladığı şiir, yazı ve çeviri şiirleri ile tanınan Yücel, 1965`ten sonra siyasal konularda da ürün verdi.

12 Mart 1971 döneminde Che Guevara ve Mao'dan çeviriler yaptığı gerekçesiyle 15 yıl hapse mahkum oldu. 1974’de çıkarılan genel afla dışarı çıktı. Dışarı çıkışının ardından hapiste yazdığı Bir Siyasinin Şiirleri adlı kitabını yayımladı. 12 Eylül 1980 sonrasında müstehcen olduğu iddiasıyla "Rengahenk" adlı kitabı toplatıldı.

1962'de İngiltere'deyken, 1709 yılından kalma, Latin harfleriyle taş baskısı olarak basılmış bir Türkçe dilbilgisi kitabı bulması geniş yankı uyandırdı.Şiirlerinde argo ve müstehcen sözlere çok sık yer veren, bu nedenle zaman zaman dikkatleri üzerine çekip koğuşturmaya uğrayan Yücel, ilk şiirlerini 1950 yılında `Yazma` adlı kitapta toplamıştır.Can Yücel, taşlama ve toplumsal duyarlılığın ağır bastığı şiirlerinde, yalın dili ve buluşları ile dikkati çekti.

Can Yücel'in ilham kaynakları ve şiirlerinin konuları; doğa, insanlar, olaylar, kavramlar, heyecanlar, duyumlar ve duygulardır. Şiirlerinin çoğunda sevdiği insanlar vardır. 'Maaile' şairin kitaplarından birine koyduğu bir ad. Can Yücel için ailesi çok önemlidir: eşi, çocukları torunları, babası.. Bu insanlarla olan sevgi dolu yaşamı şiirlerine yansımıştır. 'Küçük Kızım Su'ya', 'Güzel'e', 'Yeni Hasan'a Yolluk', 'Hayatta Ben En çok Babamı Sevdim' bu sevgi şiirlerinden bazılarıdır.

Can Yücel ayrıca Lorca, Shakespeare, Brecht gibi ünlü yazarların oyunlarından çeviriler yaptı. Shakespeare çevirileri (Hamlet, Fırtına, Bir Yaz Gecesi Rüyası) aslına tam olarak bağlı kalmasa da son derece başarılıdır. Shakespeare'in ünlü 'to be or not to be' sözünü 'bir ihtimal daha var, o da ölmek mi dersin' şeklinde Türkçeleştirmiştir. 1959'da ilk baskısı yayımlanan 'Her Boydan' adlı kitabında dünya şairlerinin şiirlerini serbest ama çok başarılı bir biçimde Türkçeye çevirmiştir.</p>
        </div>
     
        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>