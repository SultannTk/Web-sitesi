<?php
include 'baglanti.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kategori_adi = $_POST['kategori_adi'];
    $kategori_aciklama = $_POST['kategori_aciklama'];

    $stmt = $baglan->prepare("INSERT INTO kategoriler (kategori_adi, kategori_aciklama) VALUES (?, ?)");
    $stmt->bind_param("ss", $kategori_adi, $kategori_aciklama);

    if ($stmt->execute()) {
        echo "Kategori başarıyla eklendi!";
    } else {
        echo "Hata: " . $stmt->error;
    }

    $stmt->close();
    $baglan->close();
}
?>

<form action="kategori_ekle.php" method="POST">
    <label>Kategori Adı:</label>
    <input type="text" name="kategori_adi" required><br>

    <label>Kategori Açıklaması:</label>
    <textarea name="kategori_aciklama" required></textarea><br>

    <button type="submit">Kategori Ekle</button>
</form>
