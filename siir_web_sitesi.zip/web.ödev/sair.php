<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a{
            text-decoration: none;
            color: aliceblue;
        }
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        section{
            width: 200px;
            height: 200px;
            float: left;
            text-align: center;
        }
        section img{
            width: 120px;
            height: 120px;
            background-size: cover;
            border-radius: 60px;
        }
        .kutum{
            margin-top: 60px;
            margin-bottom: 60px;
            margin-left: 340px;
        }
        section img:hover{
            width: 140px;
            height: 140px;
            border-radius: 70px;
        }
        section a{
            text-decoration: none;
            color: black;
        }
    </style>
</head>
<body>
    
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>
       <div class="kutum">
        <section>
           <a href="sair_bilgi1.php"><img src="cemal.webp" alt="">
            <p>Cemal Süreya</p></a> 
        </section>
        <section>
            <a href="sair_bilgi2.php"><img src="ATTİLA İLHAN.webp" alt="">
            <p>Attila İlhan</p></a>
        </section>
        <section>
            <a href="sair_bilgi4.php"><img src="Cahit.jpg" alt="">
            <p>Cahit Sıtkı Tarancı</p></a>
        </section>
        <section>
            <a href="sair_bilgi5.php"><img src="Can.webp" alt="">
            <p>Can Yücel</p></a>
        </section>
        <section  style="clear: both;">
            <a href="sair_bilgi3.php"><img src="MEHMET AKİF ERSOY.webp" alt="">
            <p>Mehmet Akif Ersoy</p></a>
        </section>
        <section>
            <a href="sair_bilgi6.php"><img src="Necip.jpg" alt="">
            <p>Necip Fazıl Kısakürek</p></a>
        </section>
        <section>
            <a href="sair_bilgi7.php"><img src="Orhan.jpg" alt="">
            <p>Orhan Veli Kanık</p></a>
        </section>
        <section>
            <a href="sair_bilgi8.php"><img src="özdemir.webp" alt="">
            <p>Özdemir Asaf</p></a>
        </section>
       </div>
       <div style="clear: both;"></div>


        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>