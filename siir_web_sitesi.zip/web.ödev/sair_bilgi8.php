<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a{
            text-decoration: none;
            color: aliceblue;
        }
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        .hayat{
            width: 80%;
            height: 700px;
            margin-left: 180px;
            margin-top: 50px;
        }
        .hayat img{
            width: 200px;
            height: 200px;
            border-radius: 100px;
        }
    </style>
</head>
<body>
    
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php#tür">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>

        <div class="hayat">
            <center>
                <img src="özdemir.webp" alt="">
            <h2>ÖZDEMİR ASAF</h2>
            </center>
            <p>Özdemir Asaf (11 Haziran 1923, Ankara - 28 Ocak 1981, İstanbul), Cumhuriyet dönemi Türk şairlerdendir.[1]

11 Haziran 1923 tarihinde Ankara'da doğdu. Asıl adı Halit Özdemir Arun'dur. Babası Mehmet Asaf Şura-yı Devlet'in üyelerindendir. Babasının öldüğü yıl, 1930, Galatasaray Lisesi'nin ilk kısmına girdi. 1941 yılında 11. sınıfta, bir ek sınavla Kabataş Erkek Lisesi'ne geçip 1942 yılında mezun oldu. Hukuk Fakültesi'ne, İktisat Fakültesi'ne (3. sınıfa kadar) ve bir yıl Gazetecilik Fakültesi'ne devam etti. Bu arada Tanin ve Zaman gazetelerinde çalıştı ve çeviriler yaptı.

İlk yazısı Servet-i Fünûn (Uyanış) dergisinde çıktı. 1951 yılında Sanat Basımevi'ni kurdu ve kitaplarını Yuvarlak Masa Yayınları adı altında yayımladı. 1962'de Mehmet Ali Aybar öncülüğünde kurulan Temel Hakları Yaşatma Derneği'nin kurucularından oldu.[2]

28 Ocak 1981'de hayata veda eden Özdemir Asaf'ın ilk eşi Sabahat Selma Tezakın'dan Seda isimli bir kızı; ikinci eşi Yıldız Moran'dan ise Gün, Olgun ve Etkin adında üç oğlu vardır.</p>
        </div>
     
        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>