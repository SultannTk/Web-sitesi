<?php
include("baglanti.php");

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sorgu = $baglan->prepare("DELETE FROM eklenen WHERE id = ?");
    $sorgu->bind_param("i", $id);

    if ($sorgu->execute()) {
        echo "<script>alert('Şiir başarıyla silindi.'); window.location.href='anapanel.php';</script>";
    } else {
        echo "<script>alert('Şiir silinirken bir hata oluştu.'); window.location.href='anapanel.php';</script>";
    }

    $sorgu->close();
} else {
    echo "<script>alert('Geçersiz istek.'); window.location.href='anapanel.php';</script>";
}
?>
