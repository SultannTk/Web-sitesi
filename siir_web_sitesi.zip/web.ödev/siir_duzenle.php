<?php
include 'baglanti.php'; 


if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Hata: Geçerli bir şiir ID'si belirtilmedi.");
}

$id = $_GET['id'];


$stmt = $baglan->prepare("SELECT * FROM siirler WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    die("Hata: Şiir bulunamadı.");
}

$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şiir Düzenle</title>
</head>
<body>
    <form action="siir_duzenle.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        
        <label>Kategori:</label>
        <input type="text" name="kategori_id" value="<?php echo htmlspecialchars($row['kategori_id']); ?>" required><br>

        <label>Başlık:</label>
        <input type="text" name="baslik" value="<?php echo htmlspecialchars($row['baslik']); ?>" required><br>

        <label>Şiir:</label>
        <textarea name="siir" required><?php echo htmlspecialchars($row['siir']); ?></textarea><br>

        <label>Şair:</label>
        <input type="text" name="sair" value="<?php echo htmlspecialchars($row['sair']); ?>" required><br>

        <button type="submit">Şiiri Güncelle</button>
    </form>
</body>
</html>
