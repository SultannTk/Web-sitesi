<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a{
            text-decoration: none;
            color: aliceblue;
        }
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        .hayat{
            width: 80%;
            height: 700px;
            margin-left: 180px;
            margin-top: 50px;
        }
        .hayat img{
            width: 200px;
            height: 200px;
            border-radius: 100px;
        }
    </style>
</head>
<body>
   
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php#tür">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>

        <div class="hayat">
            <center>
                <img src="Necip.jpg" alt="">
            <h2>NECİP FAZIL KISAKÜREK</h2>
            </center>
            <p>Yazdığı ilk şiirin on üç, on dört yaşlarında Milli mücadele zamanlarındayken Tercüman gazetesinin edebi ekinde çıktığını söyleyen Necip Fazıl Kısakürek’in kayıtlarda olan ilk şiiri 1923 yılının temmuz ayında Yeni Mecmua’da yayımlanan “Kitabe” başlıklı şiiridir. Necip Fazıl Kısakürek, bu şiiri daha sonra “Örümcek Ağı” adlı şiir kitabına “Bir Mezar Taşı” adlı başlık ile alacaktır. Kitabe şiirinin Yeni Mecmua dergisinde yayımlanmasının ardından 1939 senesine kadar geçen sürede birçok şiir ve hikayesi farklı dergi ve gazetelerde yayımlanmaya devam eder. Necip Fazıl Kısakürek’in şiir ve hikayelerinin yayımlandığı dergiler; Yeni Mecmua, Milli Mecmua, Hayat, Anadolu ve Varlık’tır. Dönemin önde gelen bu dergilerinin yanı sıra Necip Fazıl Kısakürek’in şiir ve hikayeleri Cumhuriyet gazetesinde de kendilerine yer bulur. Özellikle Hayat dergisinde çıkan şiirleri ile Necip Fazıl Kısakürek tüm dikkatleri üzerinde toplar. Bu yıllarda yazdığı şiirleri “Örümcek Ağı” ve “Kaldırımlar” adlı şiir kitaplarının içerisinde yerlerini alacaktır. Şiir ve hikayelerinde yakaladığı bu başarı sebebi ile Necip Fazıl Kısakürek hakkında takdir ve övgü yazıları yazılır. Necip Fazıl Kısakürek’in şiir kitabına adını veren Kaldırımlar başlıklı uzun şiiri Necip Fazıl Kısakürek’in “Kaldırımlar Şairi” olarak tanınmasını ve ün kazanmasını sağlar. 1932 senesinde “Ben ve Ötesi” adlı üçüncü şiir kitabını ve 1933 senesinde de düz yazılarını bir araya getirdiği “Birkaç Hikaye Birkaç Tahlil” adlı kitabını yayımlar. Necip Fazıl Kısakürek’in tiyatro alanında verdiği ilk eser olan Tohum, 1935 senesinde yayımlanır. Necip Fazıl Kısakürek’in tiyatroya olan ilgisi usta tiyatrocu Muhsin Ertuğrul’un etkisi ile olur. Necip Fazıl’ın yazdığı ilk tiyatro eseri Tohum, Muhsin Ertuğrul tarafından sahnelenir.

1934 senesinde Nakşibenbi şeyhi Abdülhakim Arvasi ile tanışması ile Necip Fazıl Kısakürek’in sanat anlayışı ve eserlerinin içeriğinde mistik ve dini bir değişim kendini göstermeye başlar. Ankara’da memur olan Necip Fazıl Kısakürek 1936 senesinde döneminin yüzeysel ve maddeci dergilerine karşı manevi derinliği olan ve sanatsal değer taşıyan Ağaç dergisini çıkarmaya başlar. Haftalık olarak çıkan Ağaç dergisi 7. sayıdan sonra İstanbul’a taşınır. Ağaç dergisi; Abdülhak Şinasi Hisar, Burhan Toprak, Fikret Adil, Ahmet Kutsi Tecer, Mustafa Şekip Tunç, Ahmet Hamdi Tanpınar, Sait Faik Abasıyanık, Sabahattin Ali, Bedri Rahmi Eyüpoğlu ve Muhip Dıranas gibi kaliteli ve değerli sanat adamlarını bir araya getirir. Ağaç dergisi beklenilen ilgiyi görmediğinden ve maddi yetersizlikten dolayı 17. sayıda basım hayatına son vermek zorunda kalır. Necip Fazıl Kısakürek’in Tohum adlı tiyatro oyunu eleştirmenler tarafından beğenilse de izleyicinin ilgisini toplayamaz. Necip Fazıl Kısakürek, Nakşibenbi şeyhi Abdülhalim Arvasi’yi tanımasının mistik ve metafizik bir eseri olan Bir Adam Yaratmak adlı oyunu yazar. Necip Fazıl Kısakürek’in Muhsin Ertuğrul’un başrolü canlandırması ile büyük beğeni toplayan Bir Adam Yaratmak adlı oyundan sonra 1942 senesine kadar yazdığı tiyatroları birçok şehir tiyatrolarında sahne alır. Necip Fazıl Kısakürek, 1943 senesinde Büyük Doğu dergisini çıkarır. 1950 senesinde ise Büyük Doğu Cemiyeti adı altında kurduğu siyasi bir derneğe kuruculuk eder. Başkanı olduğu bu derneğin adı altında ülkenin çeşitli yerlerinde verdiği konferanslar ile büyük kitlelere hitap etme imkanı bulan Necip Fazıl Kısakürek, hem Büyük Doğu dergisinde yazdığı siyasi yazıları hem de siyasi hareketleri sebebi ile farklı hükümetler döneminde takibe alınır ya da mahkum edilir. Necip Fazıl Kısakürek, 1950 senesinden sonra en verimli dönemlerini yaşar. Şiir kitaplarını yeniden düzenler. Ayrıca hikaye, roman, tiyatro, senaryo, hatıra, dini ve tasavvufi eserlerin yanı sıra siyasi ve tarihi incelemeleri de bu dönemimde kaleme alır.</p>
        </div>
     
        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>