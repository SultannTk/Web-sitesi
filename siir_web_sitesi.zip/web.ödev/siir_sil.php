<?php
include 'baglanti.php'; 

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    
    $stmt = $baglan->prepare("DELETE FROM siirler WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "Şiir başarıyla silindi!";
    } else {
        echo "Hata: " . $stmt->error;
    }

    $stmt->close();
    $baglan->close();
} else {
    echo "Şiir ID'si belirtilmedi.";
}
?>
