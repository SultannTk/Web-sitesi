<?php include'header.php';?>
    <style>
        body{
            margin: 0px;
            background-color: rgb(237, 229, 205);
        }
        header img{
            width: 120px;
            border-radius: 60px;
            float: left;
        }
        header{
            width: 100%;
            background-color: rgb(70, 104, 104);
            font-size: 50px;
            padding: 15px 0 0 15px;
        }
        header a{
            text-decoration: none;
            color: aliceblue;
        }
        header p{
            margin-top: 40px;
            margin-left: 10px;
            display: inline-block;
            clear: both;
        }
        nav{
            background-color: aliceblue;
            text-align: center;
            font-size: 30px;
            border:1px;
            border-style: solid;
        }
        nav a{
            text-decoration: none;
            color: black;
            font-size: 30px;
            margin: 25px;
        }
        nav a:hover{
            text-decoration: underline;
            color: rgb(132, 125, 125);
        }
        footer{
            background-color:rgb(70, 104, 104);
            text-align: center;
            font-size: 25px;
            padding: 15px;
            border: 1px;
            border-style: solid;
            margin-top: 20px;
        }
        .hayat{
            width: 80%;
            height: 700px;
            margin-left: 180px;
            margin-top: 50px;
        }
        .hayat img{
            width: 200px;
            height: 200px;
            border-radius: 100px;
        }
    </style>
</head>
<body>
    
        <nav>
            <a href="index.php">Anasayfa</a> | <a href="sair.php">Şairler</a> | <a href="index.php#tür">Türler</a> | <a href="gelen.php">Sizden Gelenler</a> | <a href="https://sozluk.gov.tr/">Sözlük</a> | <a href="ekle.php">Şiir ekle</a>
        <a style="margin-left: 0px;" href="#"><img style="float: right; width: 30px; margin-right: 30px; margin-top: 2px;" src="Message.png" alt="Mesaj"></a>
        </nav>

        <div class="hayat">
            <center>
                <img src="MEHMET AKİF ERSOY.webp" alt="">
            <h2>MEHMET AKİF ERSOY</h2>
            </center>
            <p>Eğitim Hayatına 1878 yılında 4 yaşında başlar. Emir Buhari’de yer alan Mahalle Mektebi ilk eğitime başladığı yerdir. Mahalle Mektebinde iki yıl eğitim alır. Sonrasında Fatih İptidaisine geçer. Babasından Arapça dersleri almaya başlar. Orta okul sonrasında dönemin en gözde okullarından biri olan Mekteb-i Mülkiye’nin ali kısmına başlar. Babasının vefat etmesinin ardından ise Halkalı’da yer alan Baytar Mektep-i Ali’ne parasız yatılı olarak girmiştir. Şairimiz veterinerlik fakültesini birincilikle bitirir.

1893 yılında ise Ziraat Nezareti Umur-u Baytariye Şubesinde göreve başlar. 1913 yılında ise bu görevden istifa eder. 1898 yılında evlendi. Aynı yıllarda Resimli gazetede, Maarif Dergisinde şiirleri yayınlandı. Ayrıca Arapça, Fransızca ve Farsçadan da çeviriler yapmakta idi.

Veteriner olarak göreve başladığı ilk yıllar bile daha çok şairliği ile tanınmıştır. 1906 yılında Halkalı Baytar Mektebi’nde, 1908 yılından sonra ise Edebiyat Fakültesinde öğretmenlik yapmıştır.
1920 yılına gelindiğinde ise Mehmet Akif Ersoy Burdur milletvekili olarak meclise girdi. 1921 yılında para ödülü almamak şartı ile milli marş yarışmasına katılmayı kabul eder. Milli marşımızı kahraman ordumuza ithaf etmiştir. 12 Mart 1921 günü ise şiiri milli marşımız olarak kabul edilir. Ödül olarak verilen 500 lirayı ise Hilal-i Ahmet ve Darül- Mesai Vakfına bağışlamıştır.

Abbas Halim Paşa’nın daveti ile 1923 yılında Mısır’a giden milli şairimiz Camiül- Mısriyye Üniversitesinde 1929 ile 1936 yılları arasında Türkçe Öğretmeni olarak görev yapmıştır. 17 Haziran 1936 yılında İstanbul dönen Mehmet Akif Ersoy, 27 Aralık 1936 yılında edebi aleme göçmüştür. Kabri Edirnekapı Mezarlığında bulunmaktadır.

Mehmet Akif Ersoy’un Eserleri şu şekilde sıralayabiliriz:
* Safahat * Süleymaniye Kürsüsünde
* Hakkın Sesleri * Fatih Kürsüsünde
* Hatıralar * Asım
* Gölgeler

Bu kitapların tümü safahat genel adı ile toplanmıştır.</p>
        </div>
     
        <footer>
            &copy;POEMIX. Tüm hakları saklıdır. Bu WEB sitesi Sultan Tekercioğlu tarafından yapılmıştır.
        </footer>
</body>
</html>